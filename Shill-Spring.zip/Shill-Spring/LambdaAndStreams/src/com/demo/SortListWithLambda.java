package com.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import org.omg.Messaging.SyncScopeHelper;

public class SortListWithLambda {

	public static void main(String[] args) {
		List<String> nameList=new ArrayList<>();
		nameList.add("Arun");
		nameList.add("Kiran");
		nameList.add("Varun");
		nameList.add("Mala");
		nameList.add("Zain");
		nameList.add("Kirthi");
		nameList.add("Hamid");
		
		System.out.println(nameList);
		
		/*Collections.sort(nameList,(a,b)->{
			//return a.compareTo(b);
			return b.compareTo(a);
		});
		System.out.println(nameList);*/
		
		Collections.sort(nameList,(a,b)->a.compareTo(b));
		System.out.println(nameList);
		System.out.println(nameList.stream().count());
		
		Predicate<String> p=new Predicate<String>(){
			@Override
			public boolean test(String t){
				return t.contains("a");
				
			}
		};
		
		Predicate<String> p1= t->t.contains("a");
		
		Long count=nameList.stream().filter(a->a.contains("a")).count();
		System.out.println(count);
		nameList.stream().filter(a->a.contains("a")).forEach(System.out::println);
		
	}

}
