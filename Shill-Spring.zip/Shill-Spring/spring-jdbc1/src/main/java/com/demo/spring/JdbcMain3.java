package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

public class JdbcMain3 {

	public static void main(String[] args) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao = (EmpDao) ctx.getBean("empDaoJdbcImpl");
		String resp = dao.save(new Emp(999, "Rango", "Texax", 34000));
		System.out.println(resp);

		// System.out.println(dao.delete(999));
	}

}
