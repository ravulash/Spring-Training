package com.demo.spring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class JdbcMain2 {

	public static void main(String[] args) {
		ApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		JdbcTemplate jt=(JdbcTemplate)ctx.getBean("jt");
		
		/*jt.query(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				PreparedStatement pst=conn.prepareStatement("select * from emp");
				return pst;
			}
		},new RowCallbackHandler() {
			
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				System.out.println(rs.getInt("EMPNO")+" "+ rs.getString("Name")+" "+rs.getString("ADDRESS")+" "+rs.getDouble("SALARY"));
				
			}
		});*/
		
		//Lambda function
		jt.query((conn)->{
			PreparedStatement pst=conn.prepareStatement("select * from emp");
			return pst;
			
		},(ResultSet rs)->{
			System.out.println(rs.getInt("EMPNO")+" "+ rs.getString("Name")+" "+rs.getString("ADDRESS")+" "+rs.getDouble("SALARY"));
			
		});

		//ROwMapper Test FIND ALL
		
		List<Emp> empList=jt.query("Select * from emp",new RowMapper<Emp>(){
		
			@Override
			public Emp mapRow(ResultSet rs, int idx) throws SQLException{
			
			return new Emp(rs.getInt("EMPNO"),rs.getString("Name"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			
		}});
		for(Emp e:empList){
			System.out.println(e.getEmpId()+" "+e.getName());
		
	}
		//_____Find One__________
		
		Emp e=jt.queryForObject("Select * from emp where empno=" +200, new RowMapper<Emp>(){
			@Override
			public Emp mapRow(ResultSet rs, int idx) throws SQLException{
			
			return new Emp(rs.getInt("EMPNO"),rs.getString("Name"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			
		}});
		System.out.println(e.getEmpId()+" "+e.getName());
}
}
