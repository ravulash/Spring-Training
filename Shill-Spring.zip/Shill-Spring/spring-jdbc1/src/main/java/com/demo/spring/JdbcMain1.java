package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

public class JdbcMain1 {

	public static void main(String[] args) {
		
		ApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		JdbcTemplate jt=(JdbcTemplate)ctx.getBean("jdbcTemplate");
		
		int count=jt.update(new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection conn) throws SQLException {
				
				PreparedStatement pst =conn.prepareStatement("insert into EMP(empno,name,address,salary) values(?,?,?,?)");
				pst.setInt(1, 201);;
				pst.setString(2, "Shilpa");
				pst.setString(3, "Hyd");
				pst.setDouble(4, 50000);
				
				return pst;
			}
		});
		System.out.println("ROWS UPDATED  " +count);

	}

}
