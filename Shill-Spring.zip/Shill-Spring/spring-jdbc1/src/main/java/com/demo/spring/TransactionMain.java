package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

public class TransactionMain {

	public static void main(String[] args) {

		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao = (EmpDao) ctx.getBean("empDaoJdbcImpl");
		
		List<Emp> empList=new ArrayList<>();
		empList.add(new Emp(305,"A","Delhi",1000));
		empList.add(new Emp(306,"B","Hyd",12000));
		empList.add(new Emp(309,"C","Mumbai",13000));
		empList.add(new Emp(307,"D","Bgl",14000));
		empList.add(new Emp(308,"E","Chennai",15000));
		
		dao.saveAll(empList);
	}

}
