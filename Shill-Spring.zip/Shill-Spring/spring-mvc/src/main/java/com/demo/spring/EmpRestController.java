package com.demo.spring;

import java.util.HashMap;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("emp")
public class EmpRestController {

	static HashMap<Integer, Emp> empDb = new HashMap<>();
	static {
		empDb.put(79, new Emp(79, "Ankit", "Hyd", 45000));
		empDb.put(89, new Emp(89, "Sisant", "sec", 4322));
		empDb.put(99, new Emp(99, "sri", "usa", 5466));
		empDb.put(109, new Emp(109, "sam", "tx", 7800));
		empDb.put(119, new Emp(119, "sri", "ca", 95000));
		empDb.put(129, new Emp(129, "shiv", "ade", 489000));
		empDb.put(139, new Emp(139, "ram", "ny", 45900));
		empDb.put(149, new Emp(149, "lax", "nj", 450900));
		empDb.put(159, new Emp(159, "shilp", "fl", 450600));
		empDb.put(169, new Emp(169, "swets", "OK", 450900));

	}

	// @RequestMapping(path="/find/{empid}",method=RequestMethod.GET)
	@GetMapping(path="/find/{empid}",produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity getById(@PathVariable("empid") int id){
		if(empDb.containsKey(id)){
			Emp e=empDb.get(id);
			return ResponseEntity.ok(e);
		}else{
			return ResponseEntity.ok("Employee Not Found");
		}
	}
		
		@RequestMapping(path="/save",method=RequestMethod.POST,
				consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.TEXT_PLAIN_VALUE)
		public ResponseEntity saveEmp(@RequestBody Emp e){
			if(empDb.containsKey(e.getEmpId())){
				return ResponseEntity.ok("The Employee Exists");
			}else{
				empDb.put(e.getEmpId(),e);
				return ResponseEntity.ok("The employee Saved..");
			}
		}
	
}