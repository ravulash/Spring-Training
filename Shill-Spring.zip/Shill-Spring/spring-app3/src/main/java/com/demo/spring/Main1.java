package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.spring.service.EmpService;


public class Main1 {
	public static void main(String[] args){
		ApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		EmpService service=(EmpService)ctx.getBean("empService");
		
		System.out.println(service.registerEmp(100, "Raju", "Hyd", 45000));
	}

}
