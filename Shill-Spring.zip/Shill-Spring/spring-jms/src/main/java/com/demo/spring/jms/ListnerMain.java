package com.demo.spring.jms;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ListnerMain {
	
	public static void main(String[] args) throws Exception{
		ApplicationContext ctx=new AnnotationConfigApplicationContext(JmsListnerConfig.class);
		Thread.sleep(Long.MAX_VALUE);
		
	}

}
