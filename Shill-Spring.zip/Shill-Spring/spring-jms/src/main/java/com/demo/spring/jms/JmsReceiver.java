package com.demo.spring.jms;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class JmsReceiver {

	@Autowired
	JmsTemplate jt;
	public String receive() throws JMSException{
		TextMessage tm=(TextMessage)jt.receive();
		return tm.getText();
	}
}
