package com.demo.clients;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

public class GetClient {

	
	public static void main(String[] args) {
		
		String credentials="shantanu:welcome1";
		String encCred=new String(Base64.encodeBase64(credentials.getBytes()));
		System.out.println(encCred);
		RestTemplate rt=new RestTemplate();
		HttpHeaders headers=new HttpHeaders();
		headers.set("Accept", "application/json");
		headers.set("Authorization", "Basic "+encCred);
		
		HttpEntity he=new HttpEntity<>(headers);
		ResponseEntity<String> resp=rt.exchange("http://localhost:8080/spring-mvc/emp/find/79", HttpMethod.GET, he, String.class);
		System.out.println(resp.getBody());

	}

}
