package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class main {

	public static void main(String[] args) {
		ApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		/*Performer s=(Performer)ctx.getBean("singer");
		s.perform();*/
		
		Object s=ctx.getBean("singer");
		System.out.println(s.getClass().getName());
		
		Performer p=(Performer)s;
		p.perform();
	}

}
