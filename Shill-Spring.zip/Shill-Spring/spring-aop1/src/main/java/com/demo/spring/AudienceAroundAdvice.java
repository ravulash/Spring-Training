package com.demo.spring;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AudienceAroundAdvice {
	
	@Around("execution(* com.demo.spring.Singer.perform(..))")
	public void  invoke(ProceedingJoinPoint pjp) throws Throwable{
		//before advice
				
		System.out.println("Before Advice");
		pjp.proceed();
		//after advice
		System.out.println("After Advice");
		
		
	}

}
