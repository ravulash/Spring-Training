package com.demo.spring;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AudienceAspect {

	@Pointcut("execution(* com.demo.spring.Singer.perform(..))")
	private void pcut(){}
	
	//@Before("executing(* com.demo.spring.Singing.perform(..))")
	@Before("pcut()")
	public void takeSeat(){
		System.out.println("Audience take seats...");
	}
	
	@Before("pcut()")
	public void switchOffMobiles(){
		System.out.println("Audience Switch Off Mobiles..");
	}
	
	//@AfterReturning("executing(* com.demo.spring.Singing.perform(..))")
	@AfterReturning("pcut()")
	public void apploud(){
		System.out.println("Clap! Clap! cLAP!");
	}
}
