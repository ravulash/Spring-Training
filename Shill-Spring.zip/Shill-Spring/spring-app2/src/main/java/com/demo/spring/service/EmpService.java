package com.demo.spring.service;

import com.demo.spring.dao.EmpDao;
import com.demo.spring.entity.Emp;

public class EmpService {
	EmpDao dao;
	
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}

	public String registerEmp(int id,String name, String city,double salary){
		return dao.saveEmp(new Emp(id,name,city,salary));
	}

}
