package com.demo.spring.dao;

import com.demo.spring.entity.Emp;

public class EmpDaoJdbcImpl implements EmpDao {

	@Override
	public String saveEmp(Emp e) {
		return "JDBC: Emp Saved with id " + e.getEmpId();
		
		
	}

}
